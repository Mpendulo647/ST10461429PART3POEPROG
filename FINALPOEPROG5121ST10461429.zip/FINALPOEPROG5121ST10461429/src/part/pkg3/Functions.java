/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package part.pkg3;
import javax.swing.*;
/**
 *
 * @author RC_Student_Lab
 */



public class Functions {

    // Handles sending messages using MessageManager
    public void SendMessageFunc(SendMessageManager msgManager) {

        int numMessages;
        try {
            numMessages = Integer.parseInt(JOptionPane.showInputDialog("How many messages do you want to send?"));
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Invalid number.");
            return;
        }

        for (int i = 0; i < numMessages; i++) {
            String recipient;
            do {
                recipient = JOptionPane.showInputDialog("Enter recipient phone number (+27XXXXXXXXX):");
            } while (!msgManager.checkRecipientCell(recipient));

            String content = JOptionPane.showInputDialog("Enter message " + (i + 1) + ":");

            int option = JOptionPane.showOptionDialog(null,
                    "Choose option for this message:",
                    "Message Options",
                    JOptionPane.DEFAULT_OPTION,
                    JOptionPane.INFORMATION_MESSAGE,
                    null,
                    new String[]{"Send", "Disregard", "Store"},
                    "Send");

            switch (option) {
                case 0:
                    msgManager.addMessage(content, recipient, true);
                    JOptionPane.showMessageDialog(null, "Message sent!");
                    break;
                case 1:
                    JOptionPane.showMessageDialog(null, "Message disregarded.");
                    break;
                case 2:
                    msgManager.addMessage(content, recipient, false);
                    JOptionPane.showMessageDialog(null, "Message stored for later.");
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Invalid option selected.");
            }
        }
    }

    void SendMessageFunc() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
