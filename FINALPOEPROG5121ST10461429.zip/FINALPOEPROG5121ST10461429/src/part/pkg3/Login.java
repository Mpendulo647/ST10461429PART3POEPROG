/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package part.pkg3;

import javax.swing.*;


/**
 *
 * @author RC_Student_Lab
 */

public class Login {

    Registration register;

    public Login(Registration register) {
        this.register = register;
    }

    public boolean log() {
        String username = JOptionPane.showInputDialog("Enter your username:");
        String password = JOptionPane.showInputDialog("Enter your password:");

        if (username.equals(register.RegUsername) && password.equals(register.RegPassword)) {
            JOptionPane.showMessageDialog(null,
                    "Welcome " + register.name + " " + register.surname + "!");
            return true;
        } else {
            JOptionPane.showMessageDialog(null, "Login failed. Details are incorrect.");
            return false;
        }
    }
}
