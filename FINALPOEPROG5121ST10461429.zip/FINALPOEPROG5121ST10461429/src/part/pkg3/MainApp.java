/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package part.pkg3;
import javax.swing.*;

/**
 *
 * @author RC_Student_Lab
 */


public class MainApp {

    public static void main(String[] args) {

        // Step 1: Registration
        Registration register = new Registration();
        register.userInput();

        // Step 2: Login
        Login login = new Login(register);
        boolean loginSuccess = login.log();
        if (!loginSuccess) {
            JOptionPane.showMessageDialog(null, "Exiting application. Goodbye!");
            System.exit(0);
        }

        // Step 3: Main menu
        SendMessageManager msgManager = new SendMessageManager();
        Functions funcObj = new Functions();

        String[] options = {
                "List Sent Messages",
                "Longest Sent Message",
                "Search by Message ID",
                "Search by Recipient",
                "Delete Message by Hash",
                "Generate Full Report",
                "Send Message",
                "Exit"
        };

        int choice;
        do {
            choice = JOptionPane.showOptionDialog(null,
                    "Select an option:",
                    "QuickChat Menu",
                    JOptionPane.DEFAULT_OPTION,
                    JOptionPane.INFORMATION_MESSAGE,
                    null,
                    options,
                    options[0]);

            switch (choice) {
                case 0 -> msgManager.showMessages();
                case 1 -> msgManager.showLongestMessage();
                case 2 -> msgManager.searchByMessageID();
                case 3 -> msgManager.searchByRecipient();
                case 4 -> msgManager.deleteByHash();
                case 5 -> msgManager.saveMessagesToJSON();
                case 6 -> funcObj.SendMessageFunc(msgManager);
                case 7 -> JOptionPane.showMessageDialog(null, "Goodbye!");
                default -> JOptionPane.showMessageDialog(null, "Invalid option selected.");
            }

        } while (choice != 7);

        System.exit(0);
    }
}
