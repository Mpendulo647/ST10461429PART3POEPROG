/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package part.pkg3;

/**
 *
 * @author RC_Student_Lab
 */
public class Message {

    private int messageID;
    private String message;
    private String recipient;
    private String sender;
    private String hash;

    public Message(int messageID, String message, String sender, String recipient) {
        this.messageID = messageID;
        this.message = message;
        this.sender = sender;
        this.recipient = recipient;
        this.hash = generateHash(message);
    }

    private String generateHash(String msg) {
        return Integer.toHexString(msg.hashCode()).toUpperCase();
    }

    public int getMessageID() {
        return messageID;
    }

    public String getMessage() {
        return message;
    }

    public String getRecipient() {
        return recipient;
    }

    public String getSender() {
        return sender;
    }

    public String getHash() {
        return hash;
    }

    @Override
    public String toString() {
        return "Message ID: " + messageID +
                "\nSender: " + sender +
                "\nRecipient: " + recipient +
                "\nMessage: " + message +
                "\nHash: " + hash;
    }
}

