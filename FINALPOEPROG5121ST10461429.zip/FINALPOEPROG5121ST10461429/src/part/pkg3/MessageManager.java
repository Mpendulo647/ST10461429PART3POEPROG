/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package part.pkg3;
import java.util.ArrayList;
import javax.swing.JOptionPane;


/**
 *
 * @author RC_Student_Lab
 */
public class MessageManager {

    private ArrayList<Message> messages = new ArrayList<>();
    private int nextMessageID = 1;

    // SEND MESSAGE
    public void sendMessage(String sender) {
        String recipient = JOptionPane.showInputDialog("Enter recipient:");
        String msg = JOptionPane.showInputDialog("Enter message:");

        Message message = new Message(nextMessageID++, msg, sender, recipient);
        messages.add(message);

        JOptionPane.showMessageDialog(null, "Message sent successfully!");
    }

    // VIEW ALL MESSAGES
    public void viewMessages() {
        if (messages.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No messages available.");
            return;
        }

        StringBuilder sb = new StringBuilder();
        for (Message m : messages) {
            sb.append(m).append("\n\n");
        }
        JOptionPane.showMessageDialog(null, sb.toString());
    }

    // SEARCH BY ID
    public void searchByID() {
        int id = Integer.parseInt(JOptionPane.showInputDialog("Enter Message ID:"));

        for (Message m : messages) {
            if (m.getMessageID() == id) {
                JOptionPane.showMessageDialog(null, m.toString());
                return;
            }
        }

        JOptionPane.showMessageDialog(null, "Message ID not found.");
    }

    // SEARCH BY RECIPIENT
    public void searchByRecipient() {
        String rec = JOptionPane.showInputDialog("Enter recipient name:");

        StringBuilder sb = new StringBuilder();
        for (Message m : messages) {
            if (m.getRecipient().equalsIgnoreCase(rec)) {
                sb.append(m).append("\n\n");
            }
        }

        if (sb.length() == 0) {
            JOptionPane.showMessageDialog(null, "No messages found for that recipient.");
        } else {
            JOptionPane.showMessageDialog(null, sb.toString());
        }
    }

    // DELETE MESSAGE
    public void deleteMessage() {
        int id = Integer.parseInt(JOptionPane.showInputDialog("Enter Message ID to delete:"));

        for (Message m : messages) {
            if (m.getMessageID() == id) {
                messages.remove(m);
                JOptionPane.showMessageDialog(null, "Message deleted successfully!");
                return;
            }
        }

        JOptionPane.showMessageDialog(null, "Message ID not found.");
    }

    // LONGEST MESSAGE
    public void longestMessage() {
        if (messages.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No messages available.");
            return;
        }

        Message longest = messages.get(0);
        for (Message m : messages) {
            if (m.getMessage().length() > longest.getMessage().length()) {
                longest = m;
            }
        }

        JOptionPane.showMessageDialog(null, "Longest message:\n\n" + longest);
    }

    // FULL REPORT
    public void fullReport() {
        int total = messages.size();

        StringBuilder sb = new StringBuilder();
        sb.append("FULL REPORT\n")
          .append("Total Messages: ").append(total).append("\n\n");

        for (Message m : messages) {
            sb.append(m).append("\n-------------------\n");
        }

        JOptionPane.showMessageDialog(null, sb.toString());
    }

    void storeMessage(SendMessage.Message message) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
