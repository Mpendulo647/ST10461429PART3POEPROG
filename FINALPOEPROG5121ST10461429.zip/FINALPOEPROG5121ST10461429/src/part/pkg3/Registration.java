/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package part.pkg3;
import javax.swing.*;



/**
 *
 * @author RC_Student_Lab
 */


public class Registration {

    String RegUsername;
    String name;
    String surname;
    String RegPassword;
    String cellphoneNum;

    public void userInput() {
        name = JOptionPane.showInputDialog("Enter your name:");
        surname = JOptionPane.showInputDialog("Enter your surname:");

        do {
            RegUsername = JOptionPane.showInputDialog(
                    "Enter username (must contain '_' and be less than 5 characters):");
        } while (!checkUsername(RegUsername));

        do {
            RegPassword = JOptionPane.showInputDialog(
                    "Enter password (min 8 chars, 1 uppercase, 1 digit, 1 special char):");
        } while (!checkPassword(RegPassword));

        do {
            cellphoneNum = JOptionPane.showInputDialog(
                    "Enter your cellphone number (e.g., +27831234567):");
        } while (!checkCellNumber(cellphoneNum));

        JOptionPane.showMessageDialog(null, "Registration successful!\nYou can now log in.");
    }

    public boolean checkUsername(String RegUsername) {
        if (RegUsername.contains("_") && RegUsername.length() < 5) {
            return true;
        } else {
            JOptionPane.showMessageDialog(null, "Username is incorrectly formatted.");
            return false;
        }
    }

    public boolean checkPassword(String RegPassword) {
        boolean hasMinLength = RegPassword.length() >= 8;
        boolean hasUppercase = RegPassword.matches(".*[A-Z].*");
        boolean hasDigit = RegPassword.matches(".*\\d.*");
        boolean hasSpecialChar = RegPassword.matches(".*[!@#$%^&*()].*");

        if (hasMinLength && hasUppercase && hasDigit && hasSpecialChar) {
            return true;
        } else {
            JOptionPane.showMessageDialog(null, "Password is incorrectly formatted.");
            return false;
        }
    }

    public boolean checkCellNumber(String cellphoneNum) {
        boolean hasCountryCode = cellphoneNum.startsWith("+27");
        boolean hasOnlyDigits = cellphoneNum.substring(1).matches("\\d+");
        boolean hasCorrectLength = cellphoneNum.length() == 12;

        if (hasCountryCode && hasOnlyDigits && hasCorrectLength) {
            return true;
        } else {
            JOptionPane.showMessageDialog(null, "Cell number is incorrectly formatted.");
            return false;
        }
    }
}
