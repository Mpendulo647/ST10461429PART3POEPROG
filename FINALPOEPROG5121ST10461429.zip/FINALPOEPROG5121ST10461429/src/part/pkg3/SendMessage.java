/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package part.pkg3;
import javax.swing.*;
import java.util.ArrayList;
import java.util.UUID;

/**
 *
 * @author RC_Student_Lab
 */
/**
 * The SendMessage class handles the logic for sending, storing, and managing messages.
 * It includes the Message class to represent a single message.
 */

public class SendMessage {

    // Inner class to represent individual messages
    static class Message {
        String messageHeld;
        String messageHash;
        String recipientNumber;

        public Message(String messageHeld, String recipientNumber) {
            this.messageHeld = messageHeld;
            this.recipientNumber = recipientNumber;
            // Generate a unique hash for each message
            this.messageHash = UUID.randomUUID().toString().substring(0, 8); // short hash
        }

        Message(String messageId, String recipient, String content) {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        @Override
        public String toString() {
            return "To: " + recipientNumber + "\nMessage: " + messageHeld + "\nID: " + messageHash;
        }

        Object getContent() {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        Object getMessageId() {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        Object getRecipient() {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }
    }

    // List to store messages that have been sent
    private static ArrayList<Message> messages = new ArrayList<>();

    // Main method for interaction with the user
    public static void main(String[] args) {

        Functions funcObj = new Functions();
        int choice;

        do {
            // Provide the user with a menu of options
            choice = Integer.parseInt(JOptionPane.showInputDialog(null, """
                                                                  Welcome to QuickChat
                                                                  ===================================
                                                                  Please choose from the options below:
                                                                  1. Send message(s)
                                                                  2. Show recently sent messages
                                                                  3. Exit"""));

            switch (choice) {
                case 1:
                    funcObj.SendMessageFunc();  // This calls the function to send a message
                    break;

                case 2:
                    showSentMessages();  // Shows the messages that were sent so far
                    break;

                case 3:
                    JOptionPane.showMessageDialog(null, "Exiting... Goodbye!");
                    break;

                default:
                    JOptionPane.showMessageDialog(null, "Invalid choice. Please select 1, 2, or 3.");
                    break;
            }

        } while (choice != 3);
    }

    // Displays the list of sent messages
    private static void showSentMessages() {
        if (messages.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No messages have been sent yet.");
        } else {
            StringBuilder sb = new StringBuilder();
            for (Message message : messages) {
                sb.append(message).append("\n\n");
            }
            JOptionPane.showMessageDialog(null, sb.toString());
        }
    }

    // Method to store a message into the list
    public static void storeMessage(String messageContent, String recipient) {
        Message newMessage = new Message(messageContent, recipient);
        messages.add(newMessage);
        JOptionPane.showMessageDialog(null, "Message stored successfully!");
    }

    // Method to send a message
    public static void sendMessage(String messageContent, String recipient) {
        Message newMessage = new Message(messageContent, recipient);
        messages.add(newMessage);
        JOptionPane.showMessageDialog(null, "Message sent to " + recipient);
    }

    // New method to handle multiple messages
    public static void handleMultipleMessages() {
        int numMessages = Integer.parseInt(JOptionPane.showInputDialog(null, "How many messages do you want to send?"));

        for (int i = 0; i < numMessages; i++) {
            // Collect message and recipient details
            String recipient = JOptionPane.showInputDialog(null, "Enter recipient's phone number for message " + (i + 1) + ":");
            String messageContent = JOptionPane.showInputDialog(null, "Enter your message for message " + (i + 1) + ":");

            // Present options for the user
            String[] options = {"Send Message", "Disregard Message", "Store Message to Send Later"};
            int choice = JOptionPane.showOptionDialog(null, "Choose one of the following for message " + (i + 1) + ":",
                    "Message Options", JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);

            switch (choice) {
                case 0:
                    sendMessage(messageContent, recipient); // Send message
                    break;
                case 1:
                    JOptionPane.showMessageDialog(null, "Message disregarded.");
                    break;
                case 2:
                    storeMessage(messageContent, recipient); // Store message for later
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Invalid option.");
                    break;
            }
        }
    }
}
