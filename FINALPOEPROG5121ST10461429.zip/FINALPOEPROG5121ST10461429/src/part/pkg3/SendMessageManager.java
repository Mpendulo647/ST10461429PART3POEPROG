/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package part.pkg3;
import javax.swing.*;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

/**
 *
 * @author RC_Student_Lab
 */


public class SendMessageManager {

    // List to store all messages
    private final ArrayList<Message> messages = new ArrayList<>();

    // Inner Message class
    public static class Message {
        String messageID;
        String hash;
        String content;
        String recipient;
        boolean sent;

        public Message(String content, String recipient, boolean sent) {
            this.content = content;
            this.recipient = recipient;
            this.sent = sent;
            this.messageID = createMessageID();
            this.hash = createMessageHash();
        }

        private static String createMessageID() {
            long id = (long) (Math.random() * 9000000000L) + 1000000000L;
            return String.valueOf(id);
        }

        private String createMessageHash() {
            String[] words = content.split(" ");
            String firstWord = words.length > 0 ? words[0] : "";
            String lastWord = words.length > 1 ? words[words.length - 1] : "";
            return messageID.substring(0, 2) + ":" + words.length + ":" + firstWord.toUpperCase() + lastWord.toUpperCase();
        }

        @Override
        public String toString() {
            return "Message ID: " + messageID +
                    "\nHash: " + hash +
                    "\nRecipient: " + recipient +
                    "\nContent: " + content +
                    "\nSent: " + (sent ? "Yes" : "No");
        }

        public String toJSON() {
            return "{\n" +
                    "  \"messageID\": \"" + messageID + "\",\n" +
                    "  \"hash\": \"" + hash + "\",\n" +
                    "  \"recipient\": \"" + recipient + "\",\n" +
                    "  \"content\": \"" + content + "\",\n" +
                    "  \"sent\": " + sent + "\n" +
                    "}";
        }
    }

    // Getter for messages (needed for testing)
    public ArrayList<Message> getMessages() {
        return messages;
    }

    // Validate South African number format
    public boolean checkRecipientCell(String cellphoneNum) {
        boolean valid = cellphoneNum.startsWith("+27") &&
                cellphoneNum.length() == 12 &&
                cellphoneNum.substring(1).matches("\\d+");
        if (!valid) JOptionPane.showMessageDialog(null, "Cell number is invalid.");
        return valid;
    }

    // Add a message to the list
    public void addMessage(String content, String recipient, boolean sent) {
        messages.add(new Message(content, recipient, sent));
    }

    // Display all messages
    public void showMessages() {
        if (messages.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No messages available.");
            return;
        }
        StringBuilder sb = new StringBuilder();
        for (Message m : messages) sb.append(m).append("\n----------------\n");
        JOptionPane.showMessageDialog(null, sb.toString(), "Sent Messages", JOptionPane.INFORMATION_MESSAGE);
    }

    // Show the longest message
    public void showLongestMessage() {
        if (messages.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No messages available.");
            return;
        }
        Message longest = messages.get(0);
        for (Message m : messages) {
            if (m.content.length() > longest.content.length()) longest = m;
        }
        JOptionPane.showMessageDialog(null, "Longest message:\n" + longest, "Longest Message", JOptionPane.INFORMATION_MESSAGE);
    }

    // Search message by ID
    public void searchByMessageID() {
        if (messages.isEmpty()) { JOptionPane.showMessageDialog(null, "No messages."); return; }
        String id = JOptionPane.showInputDialog("Enter Message ID to search:");
        for (Message m : messages) {
            if (m.messageID.equals(id)) {
                JOptionPane.showMessageDialog(null, m, "Message Found", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
        }
        JOptionPane.showMessageDialog(null, "Message ID not found.");
    }

    // Search messages by recipient
    public void searchByRecipient() {
        if (messages.isEmpty()) { JOptionPane.showMessageDialog(null, "No messages."); return; }
        String recipient = JOptionPane.showInputDialog("Enter recipient number to search:");
        StringBuilder sb = new StringBuilder();
        for (Message m : messages) {
            if (m.recipient.equals(recipient)) sb.append(m).append("\n----------------\n");
        }
        JOptionPane.showMessageDialog(null, sb.length() > 0 ? sb.toString() : "No messages for this recipient.");
    }

    // Delete message by hash
    public void deleteByHash() {
        if (messages.isEmpty()) { JOptionPane.showMessageDialog(null, "No messages."); return; }
        String hash = JOptionPane.showInputDialog("Enter message hash to delete:");
        for (Message m : messages) {
            if (m.hash.equals(hash)) {
                messages.remove(m);
                JOptionPane.showMessageDialog(null, "Message deleted successfully.");
                return;
            }
        }
        JOptionPane.showMessageDialog(null, "Hash not found.");
    }

    // Save all messages to JSON file
    public void saveMessagesToJSON() {
        if (messages.isEmpty()) return;
        File file = new File("messages.json");
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
            writer.write("[\n");
            for (int i = 0; i < messages.size(); i++) {
                writer.write(messages.get(i).toJSON());
                if (i < messages.size() - 1) writer.write(",\n");
            }
            writer.write("\n]");
            JOptionPane.showMessageDialog(null, "Messages saved to messages.json successfully!");
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error saving messages: " + e.getMessage());
        }
    }
}
