/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/EmptyTestNGTest.java to edit this template
 */
package part.pkg3;

import static org.testng.Assert.fail;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

/**
 *
 * @author RC_Student_Lab
 */



public class FunctionsNGTest {

    private Functions instance;

    @BeforeMethod
    public void setUp() {
        instance = new Functions();
    }

    @Test
    public void testSendMessageFuncRunsWithoutException() {
        try {
            // Call the method (GUI will appear during testing)
            instance.SendMessageFunc();
        } catch (Exception e) {
            fail("SendMessageFunc() threw an exception: " + e.getMessage());
        }
    }
}
