/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/EmptyTestNGTest.java to edit this template
 */
package part.pkg3;
import static org.testng.Assert.*;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

/**
 *
 * @author RC_Student_Lab
 */

public class MainAppNGTest {

    @BeforeMethod
    public void setUp() {
        // Nothing needed here for now
    }

    @Test
    public void testMainRunsWithoutExceptions() {
        try {
            String[] args = {};
            MainApp.main(args);
        } catch (Exception e) {
            fail("MainApp.main() threw an exception: " + e.getMessage());
        }
    }
}
