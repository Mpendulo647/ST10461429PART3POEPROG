/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/EmptyTestNGTest.java to edit this template
 */
package part.pkg3;

import static org.testng.Assert.*;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;


/**
 *
 * @author RC_Student_Lab
 */


public class SendMessageManagerNGTest {

    private SendMessageManager instance;

    @BeforeMethod
    public void setUp() {
        instance = new SendMessageManager();
    }

    @Test
    public void testCheckRecipientCell() {
        // Valid number
        assertTrue(instance.checkRecipientCell("+27831234567"));
        // Invalid number
        assertFalse(instance.checkRecipientCell("0831234567"));
        assertFalse(instance.checkRecipientCell("+271234"));
    }

    @Test
    public void testAddMessageAndShowMessages() {
        instance.addMessage("Hello World", "+27831234567", true);
        instance.addMessage("Second message", "+27839876543", false);

        // Check that messages were added
        assertEquals(instance.getMessages().size(), 2);

        // Optionally test showMessages doesn't throw exception
        instance.showMessages();
    }

    @Test
    public void testShowLongestMessage() {
        instance.addMessage("Short", "+27831234567", true);
        instance.addMessage("This is the longest message", "+27831234567", true);

        // Method call should not throw exception
        instance.showLongestMessage();
    }

    @Test
    public void testSearchByMessageID() {
        instance.addMessage("Test Message", "+27831234567", true);
        String id = instance.getMessages().get(0).messageID;

        // You can simulate search by ID logic
        assertNotNull(id);
    }

    @Test
    public void testSearchByRecipient() {
        instance.addMessage("Message 1", "+27831234567", true);
        instance.addMessage("Message 2", "+27839876543", true);

        // Search for a specific recipient
        instance.searchByRecipient(); // implement GUI prompt if needed
    }

    @Test
    public void testDeleteByHash() {
        instance.addMessage("Message to delete", "+27831234567", true);
        String hash = instance.getMessages().get(0).hash;

        // GUI method call
        instance.deleteByHash(); // implement GUI prompt if needed

        // After deletion, size should decrease (if hash matches)
        assertTrue(instance.getMessages().size() <= 1);
    }

    @Test
    public void testSaveMessagesToJSON() {
        instance.addMessage("JSON Test", "+27831234567", true);

        // Call saveMessagesToJSON (ensure no exceptions thrown)
        instance.saveMessagesToJSON();
    }
}
