/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/EmptyTestNGTest.java to edit this template
 */
package part.pkg3;

import static org.testng.Assert.*;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

/**
 *
 * @author RC_Student_Lab
 */

public class SendMessageNGTest {

    private SendMessageManager manager;

    @BeforeMethod
    public void setUp() {
        manager = new SendMessageManager();
    }

    @Test
    public void testAddMessage() {
        manager.addMessage("Hello Test", "+27831234567", true);
        assertEquals(manager.getMessages().size(), 1);
        assertEquals(manager.getMessages().get(0).content, "Hello Test");
        assertEquals(manager.getMessages().get(0).recipient, "+27831234567");
        assertTrue(manager.getMessages().get(0).sent);
    }

    @Test
    public void testCheckRecipientCell() {
        assertTrue(manager.checkRecipientCell("+27831234567")); // valid
        assertFalse(manager.checkRecipientCell("0831234567"));   // invalid
        assertFalse(manager.checkRecipientCell("+271234"));     // invalid
    }

    @Test
    public void testMessageProperties() {
        manager.addMessage("Test Message", "+27839876543", false);
        SendMessageManager.Message msg = manager.getMessages().get(0);

        assertNotNull(msg.messageID);
        assertNotNull(msg.hash);
        assertEquals(msg.content, "Test Message");
        assertEquals(msg.recipient, "+27839876543");
        assertFalse(msg.sent);
    }

    @Test
    public void testSaveMessagesToJSON() {
        manager.addMessage("JSON Test", "+27831234567", true);
        // Simply call the method to ensure no exceptions
        manager.saveMessagesToJSON();
    }

    @Test
    public void testShowLongestMessage() {
        manager.addMessage("Short", "+27831234567", true);
        manager.addMessage("This is the longest message", "+27831234567", true);
        // Call method to ensure no exceptions
        manager.showLongestMessage();
    }

    @Test
    public void testSearchAndDeletePlaceholders() {
        // These methods depend on GUI prompts; we call them to ensure no exceptions
        manager.addMessage("Message 1", "+27831234567", true);
        manager.addMessage("Message 2", "+27839876543", true);

        // GUI methods: will show JOptionPane dialogs
        // manager.searchByMessageID();
        // manager.searchByRecipient();
        // manager.deleteByHash();
        // Uncomment above lines if running manually and want to test GUI
    }
}
